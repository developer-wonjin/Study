package org.zerock.club.entity;

public enum ClubMemberRole {

    USER,MANAGER,ADMIN

}
